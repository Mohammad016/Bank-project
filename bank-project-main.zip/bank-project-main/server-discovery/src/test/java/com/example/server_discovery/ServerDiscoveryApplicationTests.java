package com.example.server_discovery;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ServerDiscoveryApplicationTests {

	@Test
	void contextLoads() {
	}

}
