package com.example.FrontendService;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FrontendServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
