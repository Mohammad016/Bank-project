package com.example.CustomerService.Controller;

import com.example.CustomerService.pojos.Customer;
import com.example.CustomerService.service.CustomerService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.ModelAndView;

@RestController
public class CustomerController {

    @Autowired
    private CustomerService cs;
    @RequestMapping(value="/home",method=RequestMethod.GET)
    public String home() {
    	System.out.println("Hey");
    	return "CustomerPortal";
    }

    @GetMapping("/depositMoneyForm")
    public ModelAndView showDepositMoneyForm() {
        return new ModelAndView("depositMoneyForm");
    }


    @PostMapping("/depositt")
    public void depositMoney(@RequestBody Customer c) {
    	System.out.println("Leyndkfndkf");
    	int acNo=c.getAcno();
    	double balance=c.getBalance();
        Customer customer = cs.findCustomerByAccountNumber(acNo);
        System.out.println(acNo+":"+balance);
        if (customer != null) {
            customer.setBalance(customer.getBalance() + balance);
            cs.updateCustomer(customer);
            System.out.println("Yayyy");
        } else {
        	System.out.println("Oops");
        }
    }

    @GetMapping("/withdrawMoneyForm")
    public ModelAndView showWithdrawMoneyForm() {
        return new ModelAndView("withdrawMoneyForm");
    }


    @PostMapping("/withdraw")
    public String withdrawMoney(@RequestBody Customer c) {
    	int acNo=c.getAcno();
    	double balance=c.getBalance();
        Customer customer = cs.findCustomerByAccountNumber(acNo);
        System.out.println("Outside");
        if (customer != null && customer.getBalance() >= balance) {
        	System.out.println("Inside");
            customer.setBalance(customer.getBalance() - balance);
            cs.updateCustomer(customer);
            return "success";
        } else {
        	return "Oops";
        }
    }
    @PostMapping("/checkBalance")
    public Customer checkBalance(@RequestBody Customer c) {
    	int acNo=c.getAcno();
        Customer customer = cs.findCustomerByAccountNumber(acNo);
        if (customer != null) {
        	return customer;
        } else {
        	return null;
        }
    }

    @GetMapping("/checkBalanceForm")
    public ModelAndView showCheckBalanceForm() {
        return new ModelAndView("checkBalanceForm");
    }


}
